import { FiltertaskPipe } from './filtertask.pipe';

describe('FiltertaskPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltertaskPipe();
    expect(pipe).toBeTruthy();
  });
});
